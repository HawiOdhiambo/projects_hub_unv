<?php

include("db_conn_proj_unv.php"); //connect to the db


//check if the variable exists.
if(isset($_POST['proj_ref'])){
	$proj_ref=$_POST['proj_ref'];
}
if(empty($_POST['proj_ref']) ){
	$proj_ref="";
}

if(isset($_POST['implementing_office'])){
	$implementing_office=$_POST['implementing_office'];
}
if(empty($_POST['implementing_office']) ){
	$implementing_office="";
}
if(isset($_POST['grant_amt'])){
	$grant_amt=$_POST['grant_amt'];
}
if(empty($_POST['grant_amt'])){
	$grant_amt="";
}
if(isset($_POST['dates_gcf']) ){
	$dates_gcf=$_POST['dates_gcf'];;
}
if(empty($_POST['dates_gcf']) ){
	$dates_gcf="";
}
if(isset($_POST['start_date'])){
	$start_date=$_POST['start_date'];
}
if(empty($_POST['start_date']) ){
	$start_date="";
}
if(isset($_POST['duration'])){
	$duration=$_POST['duration'];
}
if(empty($_POST['duration']) ){
	$duration="";
}
if(isset($_POST['end_date'])){
	$end_date=$_POST['end_date'];
}
if(empty($_POST['end_date']) ){
	$end_date="";
}
if(isset($_POST['readiness_nap'])){
	$readiness_nap=$_POST['readiness_nap'];
}
if(empty($_POST['readiness_nap']) ){
	$readiness_nap="";
}
if(isset($_POST['type_of_readiness'])){
	$type_of_readiness=$_POST['type_of_readiness'];
}
if(empty($_POST['type_of_readiness']) ){
	$type_of_readiness="";
}
if(isset($_POST['first_disbursement_amt'])){
	$first_disbursement_amt=$_POST['first_disbursement_amt'];
}
if(empty($_POST['first_disbursement_amt']) ){
	$first_disbursement_amt="";
}
if(isset($_POST['status'])){
	$status=$_POST['status'];
}
if(empty($_POST['status']) ){
	$status="";
}


	$sql="INSERT INTO proj_details (proj_ref, implementing_office, grant_amt, dates_gcf, start_date, duration, end_date, readiness_nap, type_of_readiness, first_disbursement_amt, status)
				 VALUES('$proj_ref', '$implementing_office', '$grant_amt', '$dates_gcf', '$start_date', '$duration', '$end_date', '$readiness_nap', '$type_of_readiness', '$first_disbursement_amt', '$status')"; //insert project details query

		if (mysqli_query($conn, $sql)) {
			//echo "successful";
			header("location:home.php?success");

			}
			
		else{
			echo mysqli_error($conn);
			 

		} 
			

mysqli_close($conn);
?>