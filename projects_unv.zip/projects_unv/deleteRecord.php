<?php
include("db_conn_proj_unv.php"); //connect to the db

$proj_ref=$_GET['proj_ref'];


$sql="DELETE FROM proj_details WHERE proj_ref='$proj_ref'"; //query to select the project data from the db


if($res=mysqli_query($conn, $sql)){
	echo "successful";
}

else{
	echo mysqli_error($conn);
}


?>