<?php
include("db_conn_proj_unv.php"); //connect to the db

if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
           
    } else {
        $pageno = 1;
    }  


if(isset($_GET['recs_per_page'])){
  $no_of_records_per_page=$_GET['recs_per_page'];

}
else{
   $no_of_records_per_page = 10;
}

       
        $offset = ($pageno-1) * $no_of_records_per_page;


        $total_pages_sql = "SELECT COUNT(*) FROM proj_details";

        if($result = mysqli_query($conn,$total_pages_sql)){

			$total_rows = mysqli_fetch_array($result)[0];
	        $total_pages = ceil($total_rows / $no_of_records_per_page);
	        }
         echo "<select id='selectTag' class='btn btn-default' onchange='selectFunction()'>";
         if($no_of_records_per_page==10){
          echo "<option value='5' >show 5 records</option> <option value='10' selected>show 10 records</option>  <option value='20'>show 20 records</option>  <option value='50' >show 50 records</option></select>";
         }
         if($no_of_records_per_page==5){
          echo "<option value='5' selected>show 5 records</option> <option value='10' >show 10 records</option>  <option value='20'>show 20 records</option>  <option value=50' >show 50 records</option></select> ";
         }
         if($no_of_records_per_page==20){
            echo "<option value='5'>show 5 records</option> <option value='10' >show 10 records</option>  <option value='20' selected>show 20 records</option>  <option value='50' >show 50 records</option></select> ";
         }
         if($no_of_records_per_page==50){
          echo "<option value='5'>show 5 records</option> <option value='10' >show 10 records</option>  <option value='20'>show 20 records</option>  <option value='50' selected>show 50 records</option></select>";
         }
         

        $sql = "SELECT * FROM proj_details LIMIT $offset, $no_of_records_per_page";
       

       if($res_data = mysqli_query($conn,$sql)) {
       		echo "<table class='table table-striped table-hover' id='recordsTable'><thead><tr><th></th> <th></th> <th></th><th class='proj_ref'>Project Ref</th></tr></thead><tbody>";

	       	while($row = mysqli_fetch_array($res_data)){

	            echo "<tr id='".$row['proj_ref']."'><td><button class='btn btn-info' onclick='viewInfo(this)'>View</button></td> <td><button class='btn btn-warning' onclick='editInfo(this)'>Edit</button></td>  <td ><button class='btn btn-danger' onclick='deleteInfo(this)'>Delete</button></td><td class='proj_ref'>".$row['proj_ref']."</td></tr>";

	        }
	        echo "</tbody></table>";
       }

       else{
       	echo mysqli_error($conn); 
       }
       echo"<form>";
      
       	echo "Page <input type='number' value='".$pageno."' min='1' max='".$total_pages."' onchange='pagination(this)'> of ";
       	echo $total_pages;

      
       
       echo"</form>";

?>