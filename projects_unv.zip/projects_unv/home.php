<?php

include("navbar.php"); //navbar

if(isset($_GET['success'])){

	
	echo "<script language='javascript'> alert('successful')</script>";
}

?>
<div class="container text-center">   


	<div class=jumbotron" id="mainJumbo">    

		<h3><span class="glyphicon glyphicon-plus"> </span><a href="add_records.php"> Add Record</a></h3><br>
    <h3><span class="glyphicon glyphicon-list-alt"> </span><a href="view_data.php"> View Records</a></h3>
	  
	</div>

  
</div>


</body>
</html>

