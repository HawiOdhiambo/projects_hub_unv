

<?php

include("navbar.php"); //navbar

?>

<div class='container text-center'> <div class='jumbotron' id='mainJumbo'>

</div>
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="theModalButton"></button>
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" id="modalDiv">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" id="modalDismissalButton">&times;</button>
          <h4 class="modal-title">Project Information</h4>
        </div>
        <div class="modal-body" id='modalBody'>
          <p>This is a large modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">

$(document).ready( function(){
 
	var page_no= 1;
	var recs_per_page=10; 

	page(page_no, recs_per_page)
}) ;



	 function page(page_no, recs_per_page){ //console.log("receive summary data");

	
         $.ajax(
      {
      type:'GET',
      url: "pagination.php",
      data: {pageno: page_no, recs_per_page: recs_per_page},
      success: function(response){
        
      	
        $("#mainJumbo").html(response);
        
            }
          });
    }
//triggered by the select function	
function selectFunction() {
  var recs_per_page = document.getElementById("selectTag").value;
 
 page(1, recs_per_page);
}
 function viewInfo(that){

  var proj_ref=that.parentNode.parentNode.id;
  

    $.ajax(
      {
      type:'GET',
      url: "viewRecords.php",
      data: {proj_ref: proj_ref},
      success: function(response){
    
        document.getElementById("theModalButton").click();
        $("#modalBody").html(response);
        
            }
          });




 }

  function editInfo(that){

  var proj_ref=that.parentNode.parentNode.id;
  

    $.ajax(
      {
      type:'GET',
      url: "editRecords.php",
      data: {proj_ref: proj_ref},
      success: function(response){
        
       
        document.getElementById("theModalButton").click();
        $("#modalBody").html(response);
        
            }
          });




 }

function saveChanges(){
  var proj_ref=document.getElementById("proj_ref").innerHTML;
  var implementing_office=document.getElementById("implementing_office").value;
  var grant_amt=document.getElementById("grant_amt").value;
  var dates_gcf=document.getElementById("dates_gcf").value;
  var start_date=document.getElementById("start_date").value;
  var duration=document.getElementById("duration").value;
  var end_date=document.getElementById("end_date").value;
  var readiness_nap=document.getElementById("readiness_nap").value;
  var type_of_readiness=document.getElementById("type_of_readiness").value;
  var first_disbursement_amt=document.getElementById("first_disbursement_amt").value;
  var status=document.getElementById("status").value;


    $.ajax(
      {
      type:'POST',
      url: "updateRecords.php",
      data: {proj_ref: proj_ref, implementing_office: implementing_office, grant_amt: grant_amt,
           dates_gcf: dates_gcf, start_date: start_date, duration: duration, end_date: end_date,
            readiness_nap: readiness_nap, type_of_readiness: type_of_readiness,
             first_disbursement_amt: first_disbursement_amt, status: status
            },
      success: function(response){
        
        

        if (window.confirm(response))
          {
              // They clicked Yes
            document.getElementById("modalDismissalButton").click();

          }
       
        
            }
          });
}

function deleteInfo(that) {

   if (window.confirm('Are you sure you want to delete this record?'))
          {
              // They clicked Yes
           var proj_ref=that.parentNode.parentNode.id;
           var rowIndexNumber=that.parentNode.parentNode.rowIndex;
           

            $.ajax(
              {
              type:'GET',
              url: "deleteRecord.php",
              data: {proj_ref: proj_ref},
              success: function(response){
                
                console.log(response);
                if(response='successful'){

                  alert("successfully Deleted Record");                  
                      // They clicked Yes
                  document.getElementById("recordsTable").deleteRow(rowIndexNumber);
                  //document.getElementById("modalDismissalButton").click();

                 

                }
                else{
                  alert("Unable to delete Record");
                }
               
                
                    }
                  });



          }
  
}

function pagination(that){
  var pag_no=that.value;
  
  page(pag_no, 10);

}

</script>
</body>
</html>