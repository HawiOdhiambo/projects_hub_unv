-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 27, 2019 at 05:22 AM
-- Server version: 8.0.12
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projects_unv`
--

-- --------------------------------------------------------

--
-- Table structure for table `proj_countries`
--

CREATE TABLE `proj_countries` (
  `proj_countries_id` int(11) NOT NULL,
  `proj_ref` varchar(30) NOT NULL,
  `coountry_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `proj_countries`
--

INSERT INTO `proj_countries` (`proj_countries_id`, `proj_ref`, `coountry_name`) VALUES
(1, 'ALB-RS-001', 'Albania'),
(2, 'ALB-RS-001', 'Romania'),
(3, 'BRA-RS-001', 'Brazil'),
(4, 'BRA-RS-001', 'Panama'),
(5, 'COM-RS-001', 'Comoros'),
(6, 'CRI-RS-002', 'Costa Rica'),
(7, 'DOM-RS-002', 'Dominican Republic'),
(8, 'EGY-RS-001', 'Egypt'),
(9, 'EGY-RS-001', 'Morocco'),
(10, 'GHA-RS-001', 'Ghana'),
(11, 'GHA-RS-001', 'Uganda'),
(12, 'GHA-RS-001', 'Sudan'),
(13, 'HND-RS-002', 'Honduras'),
(14, 'JOR-RS-001', 'Jordan'),
(15, 'MLY-RS-002', 'Malaysia'),
(16, 'MDV-RS-001', 'Maldives'),
(17, 'MRT-RS-002', 'Mauritania'),
(18, 'MUS-RS-002', 'Mauritius'),
(19, 'MNG-RS-003', 'Mongolia'),
(20, 'MNG-RS-004', 'Mongolia'),
(21, 'MMR-RS-001', 'Myanmar'),
(22, 'NPL-RS-001', 'Nepal'),
(23, 'NER-RS-002', 'Niger'),
(24, 'PAK-RS-003', 'Pakistan'),
(25, 'PSE-RS-002', 'Palestine'),
(26, 'SRB-RS-001', 'Serbia'),
(27, 'SSD-RS-001', 'South Sudan'),
(28, 'SSD-RS-001', 'Egypt'),
(29, 'SWZ-RS-002', 'Swaziland'),
(30, 'SWZ-RS-003', 'Swaziland'),
(31, 'ZWE-RS-001', 'Zimbabwe'),
(32, 'ZWE-RS-002', 'Zimbabwe'),
(33, 'MNE-RS-001', 'Montenegro'),
(34, 'MMR-RS-002', 'Myanmar'),
(35, 'TON-RS-002', 'Tonga'),
(36, 'TON-RS-002', 'uganda'),
(37, 'TON-RS-002', 'Tanzania'),
(38, 'TON-RS-002', 'Kenya');

-- --------------------------------------------------------

--
-- Table structure for table `proj_details`
--

CREATE TABLE `proj_details` (
  `proj_ref` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `implementing_office` varchar(50) NOT NULL,
  `grant_amt` decimal(10,2) NOT NULL,
  `dates_gcf` date NOT NULL,
  `start_date` date NOT NULL,
  `duration` int(11) NOT NULL,
  `end_date` date NOT NULL,
  `readiness_nap` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `type_of_readiness` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `first_disbursement_amt` decimal(10,2) NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `proj_details`
--

INSERT INTO `proj_details` (`proj_ref`, `implementing_office`, `grant_amt`, `dates_gcf`, `start_date`, `duration`, `end_date`, `readiness_nap`, `type_of_readiness`, `first_disbursement_amt`, `status`) VALUES
('ALB-RS-001', 'Europe Office', '300000.00', '2016-11-15', '2016-08-30', 12, '2017-08-30', 'Readiness', 'Capacity Building', '147500.00', 'Completed'),
('BRA-RS-001', 'Economy Division', '700000.00', '2018-06-20', '2018-06-20', 18, '2019-12-19', 'readiness', 'F1/NA/Other', '197450.00', 'Under Implementation'),
('COM-RS-001', 'Ecosystems', '426080.00', '2018-11-01', '2018-11-01', 24, '2020-10-21', 'readiness', 'Capacity Building', '115117.00', 'Under Implementation'),
('CRI-RS-002', 'Latin America Office', '2861917.00', '2018-10-23', '2018-10-23', 36, '2021-10-23', 'nap', 'NAP', '350575.33', 'Under Implementation'),
('DOM-RS-002', 'Latin America Office', '2998325.00', '2018-07-11', '2018-07-11', 36, '2021-06-10', 'nap', 'NAP', '1161912.00', 'Under Implementation'),
('EGY-RS-001', 'Ecosystems', '300000.00', '2017-05-02', '2017-04-24', 18, '2018-10-23', 'readiness', 'Capacity Building', '122456.00', 'Under Implementation'),
('GHA-RS-001', 'CTCN', '300150.00', '2017-05-15', '2017-05-15', 24, '2019-05-10', 'readiness', 'FI/TNA/Other', '300150.00', 'Under Implementation'),
('HND-RS-002', 'Latin  America Office', '764960.00', '2018-01-18', '2018-01-18', 18, '2019-07-19', 'readiness', 'REDD+', '243515.00', 'Under Implementation'),
('JOR-RS-001', 'West Asia Office', '300000.00', '2017-06-15', '2017-06-15', 18, '2018-12-14', 'readiness', 'Capacity Building', '150000.00', 'Under Implementation'),
('MDV-RS-001', 'Asia Pacific Office', '300000.00', '2017-06-16', '2017-06-16', 12, '2018-06-13', 'readiness', 'Capacity Building', '198545.00', 'Under Implementation'),
('MLY-RS-002', 'Asia Pacific Office', '819230.00', '2018-11-12', '2018-11-12', 24, '2020-11-13', 'readiness', 'REDD+', '465695.33', 'Under Implementation'),
('MMR-RS-001', 'CTCN', '336520.00', '2017-07-26', '2017-07-26', 12, '2018-07-26', 'readiness', 'FI/TNA/Other', '336520.00', 'Under Implementation'),
('MMR-RS-002', 'Asia Pacific Office', '300000.00', '2017-01-10', '2017-11-10', 18, '2019-05-11', 'readiness', 'Capacity Building', '115840.00', 'Under Implementation'),
('MNE-RS-001', 'Europe Office', '300000.00', '2016-11-15', '2016-08-30', 12, '2017-08-30', 'readiness', 'Capacity Building', '145300.00', 'Under Implementation'),
('MNE-RS-002', 'Asia Pacific Office', '300000.00', '2017-11-10', '2017-11-10', 18, '2019-05-11', 'readiness', 'FI/TNA/Other', '336520.00', 'Under Implementation'),
('MNG-RS-001', 'Ecosystems', '300000.00', '2018-07-20', '2018-07-20', 12, '2019-07-19', 'readiness', 'Capacity Building', '177588.00', 'Under Implementation'),
('MNG-RS-002', 'CTCN', '368000.00', '2018-02-01', '2018-02-01', 12, '2019-02-01', 'readiness', 'FI/TNA/Other', '324764.00', 'Under Implementation'),
('MNG-RS-003', 'Asia Pacific Office', '368000.00', '2018-02-01', '2018-02-01', 12, '2019-02-01', 'readiness', 'FI/TNA/Other', '250000.00', 'Under Implementation'),
('MNG-RS-004', 'Asia Pacific Office', '2895461.00', '2018-06-20', '2018-06-20', 36, '2021-06-19', 'nap', 'NAP', '406123.00', 'Under Implementation'),
('MRT-RS-002', 'Africa Office', '2670374.00', '2018-07-17', '2018-07-17', 36, '2021-07-08', 'nap', 'NAP', '742163.00', 'Under Implementation'),
('MUS-RS-002', 'CTCN', '324764.00', '2018-01-22', '2018-01-22', 15, '2019-04-19', 'readiness', 'FI/TNA/Other', '324764.00', 'Under Implementation'),
('NER-RS-002', 'Ecosystems', '300000.00', '2018-06-20', '2018-06-20', 18, '2019-12-19', 'readiness', 'Capacity Building', '138100.00', 'Requesting Funds'),
('NPL-RS-001', 'Asia Pacific Office', '2935350.00', '2017-05-15', '2017-05-15', 36, '2020-05-14', 'nap', 'NAP', '465410.00', 'Under Implementation'),
('PAK-RS-003', 'Asia Pacific Office', '2969674.00', '2018-03-02', '2018-03-03', 36, '2021-03-04', 'nap', 'NAP', '675420.00', 'Under Implementation'),
('PSE-RS-002', 'CTCN', '254100.00', '2017-10-18', '2017-10-18', 12, '2017-10-18', 'readiness', 'FI/TNA/Other', '2540100.00', 'Under Implementation'),
('SRB-RS-001', 'Europe Office', '300000.00', '2018-01-12', '2018-01-12', 12, '2019-01-12', 'readiness', 'FI/TNA/Other', '254100.00', 'Under Implementation'),
('SSD-RS-001', 'Europe Office', '300000.00', '2018-06-20', '2018-06-20', 18, '2019-12-19', 'readiness', 'Capacity Building', '153176.00', 'Under Implementation'),
('SWZ-RS-002', 'Ecosystems', '299032.00', '2018-03-12', '2018-03-12', 24, '2020-03-13', 'readiness', 'Capacity Building', '83046.00', 'Under Implementation'),
('SWZ-RS-003', 'Africa Office', '2796359.00', '2018-06-28', '2018-06-28', 36, '2021-06-27', 'nap', 'NAP', '744662.00', 'Under Implementation'),
('TON-RS-002', 'CTCN', '200000.00', '2017-04-20', '2017-04-20', 6, '2017-10-09', 'readiness', 'FI/TNA/Other', '200000.00', 'Under Implementation'),
('ZWE-RS-001', 'Ecosystems', '300000.00', '2018-03-05', '2018-03-05', 24, '2020-03-04', 'readiness', 'Capacity Building', '121354.00', 'Under Implementation'),
('ZWE-RS-002', 'Africa Office', '2993349.00', '2018-05-11', '2018-05-11', 36, '2021-05-13', 'nap', 'NAP', '877525.00', 'Under Implementation');

-- --------------------------------------------------------

--
-- Table structure for table `proj_names`
--

CREATE TABLE `proj_names` (
  `proj_name_id` int(11) NOT NULL,
  `proj_ref` varchar(30) NOT NULL,
  `proj_title` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `proj_names`
--

INSERT INTO `proj_names` (`proj_name_id`, `proj_ref`, `proj_title`) VALUES
(1, 'ALB-RS-001', 'Readiness support to Albania'),
(2, 'BRA-RS-001', 'Technology Needs Assessment for the Implementation of Climate Action Plans'),
(3, 'COM-RS-001', ' Establishing and strengthening National Designated Authorities or Focal Points;'),
(4, 'COM-RS-001', 'Developing strategic frameworks for engagement with the GCF, including the preparation of country programmes.'),
(5, 'CRI-RS-002', 'Building sub-national capacities for the implementation of the National Adaptation Plan in Costa Rica'),
(6, 'DOM-RS-002', 'Building capacity to advance National Adaptation Plan Process in the Dominican Republic'),
(7, 'EGY-RS-001', 'Supporting Egypt’s engagement with the Green Climate Fund: Logical framework support'),
(8, 'GHA-RS-001', 'Drought Early Warning and Forecasting System: Improving resiliency of crops to drought through strengthened early warning within Ghana, Uganda and Sudan'),
(9, 'HND-RS-002', 'Supporting strategic planning to engage with the GCF and comply with the national commitments under the Paris Agreement regarding the LULUCF sector'),
(10, 'JOR-RS-001', 'Strengthening NDA of Jordan to deliver on GCF Investment Framework'),
(11, 'MLY-RS-002', 'Accessing REDD+ result-based payments in Malaysia'),
(12, 'MDV-RS-001', 'Establishing and strengthening National Designated Authority (NDA), and developing strategic framework for engagement with the GCF in Maldives'),
(13, 'MRT-RS-002', 'Building capacity to advance National Adaptation Plan Process in Mauritania'),
(14, 'MUS-RS-002', 'Climate Change Vulnerability and Adaptation Study for Port of Port Louis'),
(15, 'MNG-RS-003', 'Scaling-up of Implementation of Low-Carbon District Heating Systems in Mongolia'),
(16, 'MNG-RS-004', 'Building capacity to advance National Adaptation Plan Process in Mongolia'),
(17, 'MNE-RS-001', ' Establishing and strengthening National Designated Authorities or Focal Points;'),
(18, 'MNE-RS-001', 'Developing strategic frameworks for engagement with the GCF, including the preparation of country programmes.'),
(19, 'MMR-RS-002', 'Establishing and Strengthening National Designated Authority (NDA), and Developing Strategic Framework for Engagement with the GCF in Myanmar'),
(20, 'MMR-RS-001', 'Strengthened drought and flood management through improved science‐based information availability and management in Myanmar'),
(21, 'NPL-RS-001', 'Building Capacity to Advance National Adaptation Plan Process in Nepal'),
(22, 'NER-RS-002', 'Building Niger’s engagement with the GCF: Establishment and strengthening of the NDA, and elaboration of a country programme identifying strategic priorities'),
(23, 'PAK-RS-003', 'Building capacity to advance National Adaptation Plan Process in Pakistan'),
(24, 'PSE-RS-002', 'Technology Road Map for the Implementation of Climate Action Plans in Palestine.'),
(25, 'SRB-RS-001', 'Developing the capacities of the Republic of Serbia for an effective engagement with the Green Climate Fund'),
(26, 'SSD-RS-001', 'Republic of South Sudan Green Climate Fund’s Readiness and Preparatory Support Project '),
(27, 'SWZ-RS-002', 'Green Climate Fund Readiness Support for Swaziland'),
(28, 'SWZ-RS-003', 'Building capacity to advance National Adaptation Plan process in Swaziland '),
(29, 'TON-RS-002', 'To develop an energy efficiency master plan for the Kingdom of Tonga and East Africa'),
(30, 'ZWE-RS-001', '1. Establishing and strengthening National Designated Authorities or Focal Points;'),
(31, 'ZWE-RS-002', 'Building capacity to advance National Adaptation Plan Process in Zimbabwe');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `proj_countries`
--
ALTER TABLE `proj_countries`
  ADD PRIMARY KEY (`proj_countries_id`),
  ADD KEY `proj_ref` (`proj_ref`);

--
-- Indexes for table `proj_details`
--
ALTER TABLE `proj_details`
  ADD PRIMARY KEY (`proj_ref`);

--
-- Indexes for table `proj_names`
--
ALTER TABLE `proj_names`
  ADD PRIMARY KEY (`proj_name_id`),
  ADD KEY `proj_ref` (`proj_ref`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `proj_countries`
--
ALTER TABLE `proj_countries`
  MODIFY `proj_countries_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `proj_names`
--
ALTER TABLE `proj_names`
  MODIFY `proj_name_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `proj_countries`
--
ALTER TABLE `proj_countries`
  ADD CONSTRAINT `proj_countries_ibfk_1` FOREIGN KEY (`proj_ref`) REFERENCES `proj_details` (`proj_ref`);

--
-- Constraints for table `proj_names`
--
ALTER TABLE `proj_names`
  ADD CONSTRAINT `proj_names_ibfk_1` FOREIGN KEY (`proj_ref`) REFERENCES `proj_details` (`proj_ref`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
