<?php
include("db_conn_proj_unv.php"); //connect to the db

$proj_ref=$_GET['proj_ref'];


$sql="SELECT * FROM proj_details WHERE proj_ref='$proj_ref'"; //query to select the project data from the db

	 

//run location_data query
	if($res=mysqli_query($conn, $sql)){

		while($row = mysqli_fetch_array($res)){
			//var_dump($row);
			echo "<label> Project reference: </label><p id='proj_ref'>".$row['proj_ref']."<p><br>

				<label>Implementing_office: </label><br> 
				<input type='text' name='implementing_office' id='implementing_office' class='form-control'value='".$row['implementing_office']."'><br> 

				<label> Grant Amount (USD): </label><br>
				<input type='text' name='grant_amt' id='grant_amt' class='form-control' value='".$row['grant_amt']."'><br>

				<label> Dates from GCF: </label><br>
				<input type='date' name='dates_gcf' id='dates_gcf' class='form-control' value='".$row['dates_gcf']."'><br>

				<label> Start Date:</label><br>
				 <input type='date' name='start_date' id='start_date' class='form-control' value='".$row['start_date']."'<br>

				<label> Duration(months):</label><br>
				 <input type='text' name='duration' id='duration' class='form-control'  value='".$row['duration']."'><br>

				<label> End Date:</label><br>
				<input type='date' name='end_date' id='end_date' class='form-control' value='".$row['end_date']."'><br>

				<label>  Readiness or NAP:</label> <br>
				<input type='text' name='readiness_nap' id='readiness_nap' class='form-control' value='".$row['readiness_nap']."'><br>

				<label> Type of Readiness:</label><br>
				<input type='text' name='type_of_readiness' id='type_of_readiness' class='form-control' value='".$row['type_of_readiness']."'><br>

				<label> First Disbursment Amount :</label><br>
				<input type='text' name='first_disbursement_amt' id='first_disbursement_amt' class='form-control' value='".$row['first_disbursement_amt']."'><br>

				<label> Status: </label><br> <input type='text' name='status' id='status' class='form-control' value='".$row['status']."'>";

		}

		echo "<br><br> <button type='button' class='btn btn-success btn-block' onclick='saveChanges()' > Save Changes </button><br><br>";

	}
	else{
		echo mysqli_error($conn);
	}
?>