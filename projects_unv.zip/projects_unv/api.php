<?php

// Program to display complete URL 
include("db_conn_proj_unv.php"); 
if(isset($_SERVER['PHP_SELF'])){

 $link=$_SERVER['PHP_SELF']; 

//echo $link;
//echo "<br>".$_SERVER['HTTP_HOST'];

$link_array=explode("/", $link); //separate link

//var_dump($link_array);


if($link_array[3]=='projects'){
//echo 'projects';

	if($link_array[4]=='all'){

		$proj_arr=array();
   		 $proj_arr["records"]=array();

		$sql="SELECT * FROM proj_details";


		if ($result=mysqli_query($conn, $sql)) {
			//echo "successful";
				while($row = mysqli_fetch_array($result)){

			
		        $proj_item=array(
		            "Project reference:" => $row['proj_ref'],
		            "Implementing_office:" => $row['implementing_office'],
		            "Grant Amount (USD): " =>$row['grant_amt'],
		            "Dates from GCF: " => $row['dates_gcf'],
		            "Start Date:" => $row['start_date'],
		            "Duration(months):" => $row['duration'],
		              "End Date:" => $row['end_date'],
		            "Readiness or NAP:" =>$row['readiness_nap'],
		              "Type of Readiness:" => $row['type_of_readiness'],
		            "First Disbursment Amount :" => $row['first_disbursement_amt'],
		            "Status:" => $row['status']
		        );
		 
		        array_push($proj_arr["records"], $proj_item);


				}

				//var_dump($proj_arr);
				 echo json_encode($proj_arr);

			}
			
		else{
			echo mysqli_error($conn);
			 

		} 
			


	}

	if($link_array[4]=='country'){

		if(isset($link_array[5])){
			echo $link_array[5];
			$countryName= $link_array[5];


			$proj_arr=array();
   		 	$proj_arr["records"]=array();

			$sql="SELECT * FROM proj_details 
					INNER JOIN  proj_countries ON proj_countries.proj_ref=proj_details.proj_ref 
					WHERE proj_countries.coountry_name LIKE '%$countryName%%' ";

			if ($result=mysqli_query($conn, $sql)) {
			//echo "successful";
				while($row = mysqli_fetch_array($result)){

			
		        $proj_item=array(
		            "Project reference:" => $row['proj_ref'],
		            "Implementing_office:" => $row['implementing_office'],
		            "Grant Amount (USD): " =>$row['grant_amt'],
		            "Dates from GCF: " => $row['dates_gcf'],
		            "Start Date:" => $row['start_date'],
		            "Duration(months):" => $row['duration'],
		              "End Date:" => $row['end_date'],
		            "Readiness or NAP:" =>$row['readiness_nap'],
		              "Type of Readiness:" => $row['type_of_readiness'],
		            "First Disbursment Amount :" => $row['first_disbursement_amt'],
		            "Status:" => $row['status']
		        );
		 
		        array_push($proj_arr["records"], $proj_item);


				}

				//var_dump($proj_arr);
				 echo json_encode($proj_arr);

			}
			
		else{
			echo mysqli_error($conn);
			 

		} 

		}
	}


	if($link_array[4]=='status'){

		if(isset($link_array[5])){
			echo $link_array[5];
			$status= $link_array[5];


			$proj_arr=array();
   		 	$proj_arr["records"]=array();

			$sql="SELECT * FROM proj_details 
					INNER JOIN  proj_countries ON proj_countries.proj_ref=proj_details.proj_ref 
					WHERE proj_details.status LIKE '%$status%%' ";

			if ($result=mysqli_query($conn, $sql)) {
			//echo "successful";
				while($row = mysqli_fetch_array($result)){

			
		        $proj_item=array(
		            "Project reference:" => $row['proj_ref'],
		            "Implementing_office:" => $row['implementing_office'],
		            "Grant Amount (USD): " =>$row['grant_amt'],
		            "Dates from GCF: " => $row['dates_gcf'],
		            "Start Date:" => $row['start_date'],
		            "Duration(months):" => $row['duration'],
		              "End Date:" => $row['end_date'],
		            "Readiness or NAP:" =>$row['readiness_nap'],
		              "Type of Readiness:" => $row['type_of_readiness'],
		            "First Disbursment Amount :" => $row['first_disbursement_amt'],
		            "Status:" => $row['status']
		        );
		 
		        array_push($proj_arr["records"], $proj_item);


				}

				//var_dump($proj_arr);
				 echo json_encode($proj_arr);

			}
			
		else{
			echo mysqli_error($conn);
			 

		} 

		}
	}


}

} 
  
// Display the complete URL 

?> 