<?php
include("db_conn_proj_unv.php"); //connect to the db

$proj_ref=$_GET['proj_ref'];



$sql_proj_title="SELECT  proj_title FROM proj_names WHERE proj_ref='$proj_ref'"; //select the proj_titles

	if($res_proj_title=mysqli_query($conn, $sql_proj_title)){
		echo "<br><label> Project Title: </label>";

		while($row_proj_title = mysqli_fetch_array($res_proj_title)){
			//var_dump($row);
			echo "<br>".$row_proj_title['proj_title']."<br><br>";

		}

	}



$sql="SELECT * FROM proj_details WHERE proj_ref='$proj_ref'"; //query to select location data from the db

	 

//run location_data query
	if($res=mysqli_query($conn, $sql)){

		while($row = mysqli_fetch_array($res)){
			//var_dump($row);
			echo "<label> Project reference: </label><br>".$row['proj_ref']."<br><label>Implementing_office: </label><br>".$row['implementing_office']."<br> <label> Grant Amount (USD): </label><br>".$row['grant_amt']."<br><label> Dates from GCF: </label><br>".$row['dates_gcf']."<br><label> Start Date:</label><br>".$row['start_date']."<br><label> Duration(months):</label><br>".$row['duration']."<br><label> End Date:</label><br>".$row['end_date']."<br><label>  Readiness or NAP:</label> <br>".$row['readiness_nap']."<br><label> Type of Readiness:</label><br>".$row['type_of_readiness']."<br><label> First Disbursment Amount :</label><br>".$row['first_disbursement_amt']."<br><label> Status: </label><br>".$row['status'];

		}

	}


$sql_countries="SELECT coountry_name FROM proj_countries WHERE proj_ref='$proj_ref'"; //select the proj_titles

	if($res_countries=mysqli_query($conn, $sql_countries)){
		echo "<br><br><label> Countries: </label>";

		while($row_countries = mysqli_fetch_array($res_countries)){
			//var_dump($row);
			echo "<p>".$row_countries['coountry_name']."</p>";

		}

	}


?><br>