<?php

include("navbar.php"); //navbar

?>

<div class="container text-center">    

	<div class="jumbotron" id="mainJumbo"> 
	<h3 class="text-danger">ADD NEW PROJECT	</h3>
  <br>  
    <form action="insert_proj_details.php" method="POST">
      <div class="form-group">
       <label for="proj_ref"> Project Ref: </label>
      <input type="text" name="proj_ref" id="proj_ref" class="form-control" required placeholder="XXX-XX-XXX">
      </div>

      <div class="form-group">
      <label for="implementing_office">Implementing Office: </label>
      
       <select name="implementing_office"  id="implementing_office"  class="form-control">

          <option disabled selected>Select below: </option>
          <option value="Asia Pacific Office">Asia Pacific Office</option>
          <option value="CTCN">CTCN</option>   
          <option value="Ecosystems">Ecosystems</option>
          <option value="Africa Office">Africa Office</option>
           <option value="Europe Office">Europe Office</option>
           <option value="West Asia Office">West Asia Office</option>
          <option value="Latin America Office">Latin America Office</option>
          <option value="Economy Division">Economy Division</option>
         </select>

       </div>

       <div class="form-group">
       <label for="grant_amt">Grant Amount: </label>
      <input type="number" name="grant_amt" id="grant_amt" class="form-control" step="0.01">
      </div>

      <div class="form-group">
     <label for="dates_gcf"> Dates from GCF: </label>
      <input type="date" name="dates_gcf" id="dates_gcf" class="form-control" >
      </div>

      <div class="form-group">
      <label for="start_date">Start Date: </label>
      <input type="date" name="start_date" id="start_date" class="form-control" >
      </div>

      <div class="form-group">
      <label for="duration">Duration:(months) </label>
      <input type="number" name="duration" id="duration" class="form-control" >
     </div>

      <div class="form-group">
      <label for="end_date"> End Date: </label>
      <input type="date" name="end_date" id="end_date" class="form-control"> 
     </div>

      <div class="form-group">
      <label for="readiness_nap">Readiness or NAP </label>
          <select name="readiness_nap"  id="readiness_nap"  class="form-control">

          <option disabled selected>Select below: </option>
          <option value="readiness">Readiness</option>
          <option value="nap">National Adaptation Plans</option>   

         </select>
     </div>

      <div class="form-group">
      <label for="type_of_readiness">Type of Readiness: </label>
      <select name="type_of_readiness"  id="type_of_readiness"  class="form-control">

          <option disabled selected>Select below: </option>
          <option value="Capacity Building">Capacity Building</option>
          <option value="FI/TNA/Other">FI/TNA/Other</option>   
          <option value="NAP">NAP</option>   
          <option value="REDD+">REDD+</option>   

         </select>
     </div>

      <div class="form-group">
      <label for="first_disbursement_amt">First Disbursement Amount: </label>
      <input type="number" name="first_disbursement_amt" id="first_disbursement_amt" class="form-control" step="0.01" >
     </div>

      <div class="form-group">
     <label for="status"> Status: </label>

      <select name="status"  id="status"  class="form-control">

          <option disabled selected>Select below: </option>
          <option value="Completed">Completed</option>
          <option value="Under Implementation">Under Implementation</option>   
          <option value="Completion Report Submitted">Completion Report Submitted</option>   
          <option value="Requesting Funds">Requesting Funds</option>   

         </select>

      <br>
      <input type="submit" value="Submit" class="btn btn-success btn-block" >
    </form> 

	
	  
	</div>

  
</div>


</body>
</html>
